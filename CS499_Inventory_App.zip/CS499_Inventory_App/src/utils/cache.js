// src/utils/cache.js

const cache = {};
const cacheWithExpiration = {};
const CACHE_TTL = 60000; // Cache Time-To-Live in milliseconds

function fetchFromDatabase(key) {
    // Simulate a database fetch (replace with actual fetch logic)
    return fetch(`/api/inventory/${key}`).then(response => response.json());
}

function cacheData(key, data) {
    cacheWithExpiration[key] = {
        data,
        expiry: Date.now() + CACHE_TTL,
    };
}

async function getData(key) {
    const cached = cacheWithExpiration[key];
    if (cached && Date.now() < cached.expiry) {
        console.log("Returning cached data");
        return cached.data;
    }
    const data = await fetchFromDatabase(key);
    cacheData(key, data);
    return data;
}

export { getData };
