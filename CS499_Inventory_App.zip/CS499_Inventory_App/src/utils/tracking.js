// src/utils/tracking.js

const userActions = [];

function trackUserAction(action) {
    userActions.push({ action, timestamp: new Date() });
    console.log(`User action tracked: ${action}`);
}

function sendUserActionsToServer(actions) {
    // Implement logic to send actions to the server
    console.log("Sending user actions to server:", actions);
}

setInterval(() => {
    if (userActions.length > 0) {
        sendUserActionsToServer(userActions);
        userActions.length = 0; // Clear actions after sending
    }
}, 300000); // Send every 5 minutes

export { trackUserAction };
