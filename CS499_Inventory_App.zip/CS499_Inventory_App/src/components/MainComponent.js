import React, { useState } from 'react';

const MainComponent = () => {
    const [items, setItems] = useState([]);
    
    const addItem = (name, quantity) => {
        setItems([...items, { name, quantity }]);
    };

    return (
        <div>
            <h1>Inventory</h1>
            {/* Form to add items */}
            <ul>
                {items.map((item, index) => (
                    <li key={index}>{item.name}: {item.quantity}</li>
                ))}
            </ul>
        </div>
    );
};

export default MainComponent;
