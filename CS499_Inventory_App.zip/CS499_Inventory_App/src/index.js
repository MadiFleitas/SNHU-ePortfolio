import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './assets/styles.css'; // Optional: if you have any custom CSS

ReactDOM.render(<App />, document.getElementById('root'));
