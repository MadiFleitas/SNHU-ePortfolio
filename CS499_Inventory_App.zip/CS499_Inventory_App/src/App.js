// src/App.js

// In-memory cache with expiration
const cache = {};
const CACHE_TTL = 60000; // Cache Time-To-Live in milliseconds

// Function to fetch data from the database
async function fetchFromDatabase(key) {
    // Simulate a database fetch
    const response = await fetch(`/api/inventory/${key}`);
    return await response.json();
}

// Function to get data with caching and expiration
async function getData(key) {
    const cached = cache[key];
    if (cached && Date.now() < cached.expiry) {
        console.log("Returning cached data");
        return cached.data; // Return cached data
    } else {
        console.log("Fetching new data");
        const data = await fetchFromDatabase(key);
        cache[key] = {
            data, // Cache the actual data
            expiry: Date.now() + CACHE_TTL, // Set expiration time
        };
        return data;
    }
}

// User action tracking
const userActions = [];

function trackUserAction(action) {
    userActions.push({ action, timestamp: new Date() });
    console.log(`User action tracked: ${action}`);
}

// Function to send user actions to the server
async function sendUserActionsToServer() {
    if (userActions.length > 0) {
        console.log("Sending user actions to server:", userActions);
        // Implement API call to send actions, e.g.,
        await fetch('/api/userActions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userActions),
        });
        userActions.length = 0; // Clear actions after sending
    }
}

// Set an interval to send user actions every 5 minutes
setInterval(sendUserActionsToServer, 300000); // 300000 ms = 5 minutes

// Example function to load inventory
async function loadInventory(itemId) {
    trackUserAction(`Viewed item ${itemId}`);
    const inventoryData = await getData(itemId);
    // Code to render inventoryData on the UI
    console.log("Loaded inventory data:", inventoryData); // Placeholder for rendering
}

// Event listener for searching items
document.querySelector('#searchButton').addEventListener('click', () => {
    const searchTerm = document.querySelector('#searchInput').value;
    trackUserAction(`Searched for ${searchTerm}`);
    loadInventory(searchTerm); // Assuming loadInventory handles the search
});
